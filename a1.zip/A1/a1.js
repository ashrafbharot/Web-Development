/*********************************************************************************

* WEB322 – Assignment 1

* I declare that this assignment is my own work in accordance with Seneca Academic Policy. 

* No part of this assignment has been copied manually or electronically from any other source

* (including web sites) or distributed to other students.

*

* Name: MOHAMED ASHRAF BHAROT Student ID: 139539225 Date: 2024-01-21

*

********************************************************************************/

const readline = require('readline');
const fs = require('fs');
const path = require('path');

const rl = readline.createInterface(process.stdin,process.stdout);

function chooseDirectoriesorFiles() {
  rl.question('Do you wish to process a File (f) or directory (d): ', (opt) => {
    if (opt.toLowerCase() === 'f') {
      rl.question('Enter the file name: ', (name) => {
        fileProcess(name);
        rl.close();
      });
    } else if (opt.toLowerCase() === 'd') {
      rl.question('Enter the directory name: ', (name_dir) => {
        directoryProcess(name_dir);
        rl.close();
      });
    } else {
      console.log('Invalid Selection');
     chooseDirectoriesorFiles(); 
    }
  });
}

function fileProcess(name) {
  fs.readFile(name, 'utf8', (err, obj) => {
    if (err) {
      console.log(err.message);
    } else {
      
       
       const replace_Nextline = obj.toString().replace(/\s+/g, ' ');

       
       const array = replace_Nextline.replace(/[^\w\s\']/g, '').split(' ');
 
       const num_Char = replace_Nextline.length;
       const num_Words = array.length;
       const large_Word = array.reduce((longest, current) => {
         return current.length > longest.length ? current : longest;
      }, '');

      console.log(`Number of Characters (including spaces): ${num_Char}`);
      console.log(`Number of Words: ${num_Words}`);
      console.log(`Longest Word: ${large_Word}`);
    }
  });
}

function directoryProcess(name_dir) {
 
  fs.readdir(name_dir, (err, data) => {
    if (err) {
      console.log(err.message);
    
    } else {
      
      const arrange = data.sort((a, b) => b.localeCompare(a));

      // Output the report
      console.log(`Files (reverse alphabetical order): ${arrange.join(', ')}`);
    }
  });
}


chooseDirectoriesorFiles();

