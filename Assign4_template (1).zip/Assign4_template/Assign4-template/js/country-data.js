var countries = [
  {
    Name: "Canada",
	Capital: "Ottawa"
  },
  {
    Name: "Italy",
	Capital: "Rome"
  },
  {
    Name: "England",
	Capital: "London"
  },
  {
    Name: "Ireland",
	Capital: "Dublin"
  },
  {
    Name: "Russia",
	Capital: "Moscow"
  },
];