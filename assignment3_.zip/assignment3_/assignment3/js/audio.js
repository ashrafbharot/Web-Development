// Data for the "HTML Audio" Page

var audio = {
    controls: true, 
    source: [
        {src: "https://ia800607.us.archive.org/15/items/music_for_programming/music_for_programming_1-datassette.mp3", type: "audio/mp3"},
        {src: "https://ia800607.us.archive.org/15/items/music_for_programming/music_for_programming_1-datassette.ogg", type: "audio/ogg"}
    ]
};