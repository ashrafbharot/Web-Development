/********************************************************************************

* WEB322 – Assignment 02

*

* I declare that this assignment is my own work in accordance with Seneca's

* Academic Integrity Policy:

*

* https://www.senecacollege.ca/about/policies/academic-integrity-policy.html

*

* Name: MOHAMED ASHRAF BHAROT Student ID:139539225 Date:2024-02-02

*

********************************************************************************/
const express = require('express');
const legoData = require('./modules/legoSets');

const app = express();
const port = 8080; 


legoData.initialize()
  .then(() => {
  

    app.get('/', (req, res) => {
      res.send('Assignment 2: MOHAMED ASHRAF BHAROT - 139539225');
    });

    
    app.get('/lego/sets', (req, res) => {
      legoData.getAllSets()
        .then(allSets => res.json(allSets))
        .catch(error => res.status(500).send(`Error: ${error}`));
    });

   
    app.get('/lego/sets/num-demo', (req, res) => {
      const setNum = 'POUCH-2';
      legoData.getSetByNum(setNum)
        .then(set => res.json(set))
        .catch(error => res.status(500).send(`Error: ${error}`));
    });

    
    app.get('/lego/sets/theme-demo', (req, res) => {
      const theme = 'Gear'; 
      legoData.getSetsByTheme(theme)
        .then(sets => res.json(sets))
        .catch(error => res.status(500).send(`Error: ${error}`));
    });


    app.listen(port, () => {
      console.log(`Server is running on http://localhost:${port}`);
      console.log(`Server is running on http://localhost:${port}/lego/sets`);
      console.log(`Server is running on http://localhost:${port}/lego/sets/num-demo`);
      console.log(`Server is running on http://localhost:${port}/lego/sets/theme-demo`);
    });
  })
  .catch(error => {
    console.error(`Initialization error: ${error}`);
  });