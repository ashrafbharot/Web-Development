const setData = require("../data/setData");
const themeData = require("../data/themeData");
let sets = [];

const initialize = () => {
    return new Promise((resolve) => {
        sets = [];

        setData.forEach((set) => {
            const themeId = set.theme_id;
            const themeName = themeData.find((theme) => theme.id === themeId)?.name || 'Unknown';

            const setWithTheme = {
                ...set,
                theme: themeName,
            };

            sets.push(setWithTheme);
        });

        resolve();
    });
};

const getAllSets = () => {
    return new Promise((resolve) => {
        resolve(sets);
    });
};

const getSetByNum = (setNum) => {
    return new Promise((resolve, reject) => {
        const foundSet = sets.find((set) => set.set_num === setNum);
        if (foundSet) {
            resolve(foundSet);
        } else {
            reject("Unable to find requested set");
        }
    });
};

const getSetsByTheme = (theme) => {
    return new Promise((resolve, reject) => {
        const themeLower = theme.toLowerCase();
        const filteredSets = sets.filter((set) => set.theme.toLowerCase().includes(themeLower));

        if (filteredSets.length > 0) {
            resolve(filteredSets);
        } else {
            reject("Unable to find requested sets");
        }
    });
};

module.exports = {
    initialize,
    getAllSets,
    getSetByNum,
    getSetsByTheme,
};


initialize()
    .then(() => {
        
        getAllSets().then((allSets) => {
            console.log('All Sets:', allSets);
        });

        getSetByNum('POUCH-2')
            .then((specificSet) => {
                console.log('Specific Set:', specificSet);
            })
            .catch((error) => {
                console.error(error);
            });

        getSetsByTheme('Gear')
            .then((setsByTheme) => {
                console.log('Sets by Theme:', setsByTheme);
            })
            .catch((error) => {
                console.error(error);
            });
 });